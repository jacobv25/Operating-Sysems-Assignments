/**
 * Driver program
 *
 * Add other data structures and .cpp and .h files as needed.
 *
 * The input file is in the format:
 *
 *  [name], [priority], [CPU burst]
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

#include "PCB.h"
#include "queue.h"

using namespace std;

int main(int argc, char *argv[])
{
    std::cout << "CS 433 Programming assignment 3" << std::endl;
    std::cout << "Author: Marlo Golding and Jacob Valenzuela" << std::endl;
    std::cout << "Date: 04/08/2021" << std::endl;
    std::cout << "Course: CS433 (Operating Systems)" << std::endl;
    std::cout << "Description : This program finds the average turn-around time and waiting time for a set of processes using round robin scheduling. " << std::endl;
    std::cout << "=================================" << std::endl;

    int QUANTUM = 10;
    // Check that input file is provided at command line
    if(argc < 2 ) {
        cerr << "Usage: " << argv[0] << " <input_file> [<time_quantum>]" << endl;
        exit(1);
    }

    // Read the time quantum if provided.
    if(argc >= 3) {
        QUANTUM = atoi(argv[2]);
    }

    // Read task name, priority and burst length from the input file
    string name;
    int priority;
    int burst;

    //Queue to keep track of PCB order and 
    //a finalqueue to hold PCBs when finished
    queue q, finalqueue;

    //Keep track of time
    int time=0;

    //PCB
    PCB pcb;

    //Keep track of number of tasks
    int total_tasks=0;

    // open the input file
    std::ifstream infile(argv[1]);
    string line;
    while(getline(infile, line) ) {
        std::istringstream ss (line);
        // Get the task name
        getline(ss, name, ',');

        // Get the task priority
        string token;
        getline(ss, token, ',');
        priority = std::stoi(token);

        // Get the task burst length
        getline(ss, token, ',');
        burst = std::stoi(token);
      
        cout << name << " " << priority << " " << burst << endl;
        // TODO: add the task to the scheduler's ready queue
        // You will need a data structure, i.e. PCB, to represent a task
        //Parse the name into a PCB ID
        name = name.substr(1, name.size() - 1);
        int pcbID = std::stoi(name);
        //Create PCB
        PCB pcb(pcbID, priority, ProcState::RUNNING, burst, burst);
        //Add the new PCB to the queue
        q.add(pcb);
        //increment the total number of tasks
        total_tasks++;
    }
    // TODO: Add your code to run the scheduler and print out statistics
    while(!q.isEmpty()){
			//remove next in line
      pcb = q.remove();
      //pass the time
      int newBurst = pcb.getTempBurstTime() - QUANTUM;
      //If new burst time is greater than zero
      if(newBurst > 0)
      {
        //set the new time
        time += QUANTUM;
        //Set the PCBs burst time to the new value
        pcb.setTempBurstTime(newBurst);
        //Add the PCB to the back of the queue
        q.add(pcb);
        
      }
      else{//burst <= 0
        //set the new time
        time += pcb.getTempBurstTime();
        //zero because all tasks arrived at time=0
        pcb.setTat(time - 0);
        //waiting time = turnaroundtime - burst time
        pcb.setWt(pcb.getTat() - pcb.getBurstTime());
        finalqueue.add(pcb);
        
      }
      //cout<<"ProcessingFinished@time="<<time<<endl;

    }
    int turnaroundtimes[total_tasks], waitingtimes[total_tasks];
    int i=0;
    //print out the results from the finalqueue
    while(!finalqueue.isEmpty()){
      finalqueue.remove(pcb);
      turnaroundtimes[i] = pcb.getTat();
      waitingtimes[i] = pcb.getWt();
      i++;
      cout << "T"<<pcb.getID() << " turn-around time = " << pcb.getTat() << ", waiting time = " << pcb.getWt() << endl;
    }
    
    //calc average
		//sum turnaroundtime waitingtime
    int sum=0, tat_avg=0, wt_avg=0;
    for(int i=0; i < total_tasks; i++){
      sum += turnaroundtimes[i];
    }
    tat_avg = sum/total_tasks;
    sum=0;
    for(int i=0; i < total_tasks; i++){
      sum += waitingtimes[i];
    }
    wt_avg = sum/total_tasks;

    cout << "Average turn-around time = "<< tat_avg<<", Average waiting time = "<<wt_avg<<endl;
    return 0;
    return 0;
}

