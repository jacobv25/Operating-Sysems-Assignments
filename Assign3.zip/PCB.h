#pragma once

// Remember to add comments to your code
// ...

//number of elements in the PCBTable 
const int PCB_SIZE = 30;


// enum class of process state
// A process (PCB) in ready queue should be in READY state
enum class ProcState {NEW, READY, RUNNING, WAITING, TERMINATED};

/* 
Process control block(PCB) is a data structure representing a process in the system.
A process should have at least an ID and a state(i.e.NEW, READY, RUNNING, WAITING or TERMINATED).
It may also have other attributes, such as scheduling information (e.g. priority)
*/
class PCB {
public:
    // The unique process ID
	int id;
    // The priority of a process valued between 1-50. Larger number represents higher priority
	int priority;
	// The current state of the process.
	// A process in the ReadyQueue should be in READY state
  //for valid states see enum class ProcState
	ProcState state;

  int burstTime;
  int tempBurstTime;

  long pcbAddNum; // records number of times pcb added to readyqueue
  long pcbRemNum; // records number of times pcb removed from ready queue

  int tat;//turn-around times
  int wt; //waiting time

	// TODO: Add constructor and other necessary functions for the PCB class
  PCB(int i);
  PCB(); // default onstructor; needed to intialize pcbtable
  PCB(int i, int p, ProcState s, int burst, int tb);

  //destructor to end a process object
  ~PCB();

  //PCB id
  static int PCB_id;

  //sets priority of a PCB; must be 1-50, inclusive. Larger number represents higher priority
  void setPriority(int p);
  
  //returns priority of PCB
  int getPriority();

  //changes state of PCB
  void setState(ProcState s);
  
  //sets id of PCB. 
  void setID(int i);
  //gets id of PCB
  const int getID();

  void setkey(int i);
  const int getkey();

  //set burst times
  //SHOULD NOT BE ALLOWED
  //void setBurstTime(int bt);

  //Overloading of = (returns a reference to a PCB)
  PCB& operator=(const PCB&); 
  
  //allows PCB to be printed more easily using << operator and ostream obj cout
  friend std::ostream& operator<<(std::ostream&, const PCB&);
  friend std::ostream& operator<<(std::ostream&, const ProcState&);

  //Get the burst times
  const int getBurstTime();

  // In linked list search,
  //    == is used to compare node elements
  // but what does it mean for this client to compare
  // node elements?  
  bool operator==(PCB);  // overload == for search
  bool operator!=(PCB);  // overload != for search

  void setTat(int i){//Set Turn-Around Time
    tat = i;
  }
  int getTat(){//Get Turn-Around Time
    return tat;
  }
  void setWt(int i){//Set Waiting Time
    wt = i;
  }
  int getWt(){//Get Waiting Time
    return wt;
  }
  //set temp burst time
  void setTempBurstTime(int i);
  //get temp Burst Time
  const int getTempBurstTime();
};
