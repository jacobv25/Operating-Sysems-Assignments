// ============================================
// Hash Table
// Name: Jacob Valenzuela
// File Type: implementation htable.cpp
// =============================================

using namespace std;
#include <iostream>
#include "htable.h"

htable::htable()
{}

htable::~htable()
{}

// a simple hash function that uses % TSIZE simply
int htable::hash(int key)
{ 
  return key % TSIZE;
}

int htable::deleteIt(PCB el){

  //find out which slot by hashing the key
  int slot = hash(el.getkey());
  int slot2 = table[slot].search(el);
  if(slot2 != 0){
    //element found
    table[slot].deleteIth(slot2, el);  
  }
  return slot2;
}

// adds the element to the table and returns slot#
int htable::add(PCB element )
{
  
  int slot = hash(element.getkey());  // hash with the key part
  //** Note that this means adding the element to a slist in the slot (addRear)
  table[slot].addRear(element);
  return slot;
}

// finds element using the skey and returns the found element itself
// or a blank element  -- there is no cout in here

/**********NEW FIND*************
bool htable::find(string key, el_t& element){

  int slot = hash(key);
  el_t element;
  element.setkey(key);
  element = table[slot].search2(element);
  if (element.name == NULL){
    return false;
  } else {return true;}
}
*******************************/
// positions always start at 1

PCB* htable::find(int skey)
{ 
 int slot = hash(skey); // hash with skey
 PCB selement(skey);  // this is the element to look for in slist
 // initialize selement with just the skey
 PCB* pcb_ptr = table[slot].search3(selement); // call slist's search2 with selement which returns the found element.
 // return the pointer that now points to the new element from here (it could be blank)
 return pcb_ptr;
}

// displays the entire table with slot#s too
void htable::displayTable(ostream& os)
{
  for (int i = 0; i < 37; i++)
    { cout << i << ":" ;   
      table[i].displayAll(os); // call slist's displayAll
    }
}
