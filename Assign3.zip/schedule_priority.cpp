/**
 * Driver program
 *
 * Add other data structures and .cpp and .h files as needed.
 *
 * The input file is in the format:
 *
 *  [name], [priority], [CPU burst]
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

#include "PCB.h"
#include "htable.h"
#include "ReadyQueue.h"

using namespace std;

struct Display{
  string name;
  int turnAroundTime;
  int waitingTime;
};

int main(int argc, char *argv[])
{
    std::cout << "CS 433 Programming assignment 3" << std::endl;
    std::cout << "Author: Marlo Golding and Jacob Valenzuela" << std::endl;
    std::cout << "Date: 04/08/2021" << std::endl;
    std::cout << "Course: CS433 (Operating Systems)" << std::endl;
    std::cout << "Description : This program finds the average turn-around time and waiting time for a set of processes using priority scheduling. " << std::endl;
    std::cout << "=================================" << std::endl;

    int QUANTUM = 10;
    // Check that input file is provided at command line
    if(argc < 2 ) {
        cerr << "Usage: " << argv[0] << " <input_file> [<time_quantum>]" << endl;
        exit(1);
    }

    // Read the time quantum if provided.
    if(argc >= 3) {
        QUANTUM = atoi(argv[2]);
    }

    // Read task name, priority and burst length from the input file
    string name;
    int priority;
    int burst;
		int total_tasks = 0;
		int tempTurnAroundTime=0, tempWaitingTime;

		//hashtable
		htable hashtable;

		//ReadyQueue
		ReadyQueue readyqueue;

    // open the input file
    std::ifstream infile(argv[1]);
    string line;
    while(getline(infile, line) ) {
        std::istringstream ss (line);
        // Get the task name
        getline(ss, name, ',');

        // Get the task priority
        string token;
        getline(ss, token, ',');
        priority = std::stoi(token);

        // Get the task burst length
        getline(ss, token, ',');
        burst = std::stoi(token);

        cout << name << " " << priority << " " << burst << endl;
        // TODO: add the task to the scheduler's ready queue
        // You will need a data structure, i.e. PCB, to represent a task
				//Parse the name into a PCB ID
        name = name.substr(1, name.size() - 1);
        int pcbID = std::stoi(name);
				//The PCB pointer
        PCB* pcb_ptr;
				//Create PCB object
				PCB pcb(pcbID, priority, ProcState::RUNNING, burst, burst);
				//insert the object into the hash table so we can point to it and reference it later
        hashtable.add(pcb);
        pcb_ptr = hashtable.find(pcb.getkey()); 

				total_tasks++;

				//Add to the ready queue
        readyqueue.add(pcb_ptr);
    }
    // TODO: Add your code to run the scheduler and print out statistics
		bool firstPass = true;

    //list to keep track of turn around time
    int turnaroundtimes[total_tasks];
    //list to keep track of waiting time
    int waitingtimes[total_tasks];
    //index counter
    int i=0;
    while(!readyqueue.isEmpty()){
      
      PCB * pcb = (readyqueue.removeHighest());

      Display pcbDisp;
      pcbDisp.name = "T" + to_string(pcb->id);
      pcbDisp.turnAroundTime = pcb->getBurstTime();
      
      if (firstPass)
      {
        pcbDisp.waitingTime = 0;
      }
      else{
        //print out the Display
        pcbDisp.waitingTime = tempTurnAroundTime;
        pcbDisp.turnAroundTime += tempTurnAroundTime;
      }
      cout << pcbDisp.name << " turn-around time = " << pcbDisp.turnAroundTime << ", waiting time = " << pcbDisp.waitingTime << endl;

      //add to avg lists
      turnaroundtimes[i] = pcbDisp.turnAroundTime;
      waitingtimes[i] = pcbDisp.waitingTime;
      i++;
      tempWaitingTime += (pcb->getBurstTime());
      tempTurnAroundTime += pcb->getBurstTime();
      //first pass is over so set to false
      firstPass = false;
    }

    //calc average
    int sum=0, tat_avg=0, wt_avg=0;
    for(int i=0; i < total_tasks; i++){
      sum += turnaroundtimes[i];
    }
    tat_avg = sum/total_tasks;
    sum=0;
    for(int i=0; i < total_tasks; i++){
      sum += waitingtimes[i];
    }
    wt_avg = sum/total_tasks;

    cout << "Average turn-around time = "<< tat_avg<<", Average waiting time = "<<wt_avg<<endl;

    return 0;
}
