#include <iostream>
#include <ostream>
using namespace std;
#include "PCB.h"
// TODO: Add your implementation here


PCB::PCB(int i)
{
  id = i;
  priority = 0;
  state = ProcState::NEW;
  burstTime = 0;
  pcbAddNum = 0; // records number of times pcb added to readyqueue
  pcbRemNum = 0; // records number of times pcb removed from ready queue
  tat = 0;
  wt = 0;
  tempBurstTime = burstTime;
}

PCB::PCB()
{
  id = 0;
  priority = 0;
  state = ProcState::NEW;
  burstTime = 0;
  pcbAddNum = 0;
  pcbRemNum = 0; 
  tat = 0;
  wt = 0;
  tempBurstTime = burstTime;

}

PCB::PCB( int i, int p, ProcState s, int burst, int tempB)
{
  id = i;
  priority = p;
  state = s;
  burstTime = burst;
  tempBurstTime = tempB;
  pcbAddNum = 0;
  pcbRemNum = 0;
  tat = 0;
  wt = 0;
}

PCB::~PCB(){}

void PCB::setPriority(int p)
{
  priority = p;
}

void PCB::setState(ProcState s)
{
  state = s;
}


void PCB::setID(int i)
{
  id = i;
}
const int PCB::getID()
{
  return id;
}
void PCB::setkey(int i){
  setID(i);
}
const int PCB::getkey(){
  return getID();
}
//NOT ALLOWED TO CHANGE ORGINAL BURST TIME
// void PCB::setBurstTime(int bt)
// {
//   burstTime = bt;
// }

const int PCB::getBurstTime()
{
  return burstTime;
}

//set temp burst time
void PCB::setTempBurstTime(int i){
  tempBurstTime = i;
}
//get temp Burst Time
const int PCB::getTempBurstTime(){
  return tempBurstTime;
}

//Overloading of = (returns a reference to a llist)
PCB& PCB::operator=(const PCB& Original)
{
  id = Original.id;
  priority = Original.priority;
  state = Original.state;
  burstTime = Original.burstTime;
  tat = Original.tat;
  wt = Original.wt;
  tempBurstTime = Original.tempBurstTime;
  return *this;
}

// overload == for search based on the key part only
bool PCB::operator==(PCB OtherOne)
{
  if (id == OtherOne.id) return true; else return false;
}

bool PCB::operator!=(PCB OtherOne)
{
  if (id != OtherOne.id) return true; else return false;
}

ostream& operator<<(ostream& O, const ProcState& St)
{
  O << static_cast<std::underlying_type<ProcState>::type>(St);
  return O;
}

ostream& operator<<(ostream& O, const PCB& P)
{
  string PCBprint =  "";
  PCBprint +="ID:";
  PCBprint += to_string(P.id);
  PCBprint +="\tPriority:";
  PCBprint += to_string(P.priority);
  PCBprint +="\tBurst:";
  PCBprint += to_string(P.burstTime);
  PCBprint +="\tTempBurst:";
  PCBprint += to_string(P.tempBurstTime);
  PCBprint +="\tState:";

  string printState; // holds state of PCB as string
  switch(P.state)
  {
    case ProcState::NEW:
      printState = "NEW";
      break;
    case ProcState::RUNNING:
      printState = "RUNNING";
      break;  
    case ProcState::WAITING:
      printState = "WAITING";
      break;
    case ProcState::READY:
      printState = "READY";
      break;
    case ProcState::TERMINATED:
      printState = "TERMINATED";
      break;
  }
  
  O << PCBprint << printState;
  return O;
}

//returns priority of PCB
int PCB::getPriority()
{
  return priority;
}
