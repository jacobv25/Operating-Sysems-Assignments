//CS311 Yoshii Linked List class

// ====================================================
//HW#: HW3P1 llist
//Your name: Jacob Valenzuela
//Complier:  g++
//File type: llist.cpp implementation file
//=====================================================

using namespace std;
#include<iostream>
#include"llist.h" 

llist::llist()
{ 
  Front = NULL;
  Rear = NULL;
  count = 0;

}

llist::~llist()
{
  el_t temp;
  while(!isEmpty()){

    deleteFront(temp);
  }

}

//show rear
void llist::showRear(){

  cout << "REAR=" << Rear->Elem << endl;

}

/************************************************
PURPOSE: Returns true if the linked list is empty
PARAMETER: none
*************************************************/
bool llist::isEmpty() 
{
  if(Front==NULL && Rear==NULL && count==0){
    
    return true;
  }
  else { return false; }
} // be sure to check all 3 data members

/**************************************************
PURPOSE: Prints all the elements in the linked list 
PARAMETER: none
*************************************************/
/********
void llist::displayAll() {

  if(isEmpty()){
    cout<<"[empty]"<<endl;
  }
  else{
    Node *P;
    P = Front;
    cout << "[ ";
    while(P != NULL){
      
      cout << P->Elem << " ";
      P = P->Next;
    }
    cout << "]" << endl;
  }
}  // be sure to display horizontally in [  ] with blanks between elements
***************/
//OVERLOAD
void llist::displayAll(ostream& os) {

  if(isEmpty()){
    cout << "[empty]"<<endl;
  }
  else{
    Node *P;
    P = Front;
    cout << "[ ";
    while(P != NULL){
      
      os << P->Elem << " ";
      P = P->Next;
    }
    cout << "]" << endl;
  }
}  // be sure to display horizontally in [  ] with blanks between elements

/******************************************************  
PURPOSE: Adds an element to the rear of the linked list
PARAMETER: NewNum - element to be added
******************************************************/
void llist::addRear(el_t NewNum) { 

  if(count == 0){
    
    Front = new Node;
    Front->Elem = NewNum;
    Rear = Front;
  }
  else {
    Rear->Next = new Node;
    Rear = Rear->Next;
    Rear->Elem = NewNum;
  }
  Rear->Next = NULL;
  count++;
} // comment the 2 cases
/****************************************************
PURPOSE: Adds an element to the front of the linked list
PARAMETER: NewNum - element to be added
****************************************************/
void llist::addFront(el_t NewNum) { 

  if(count==0){
    Front = new Node;
    Front->Elem = NewNum;
    Rear = Front;
    Rear->Next = NULL;
    count++;
  }
  else{
    Node *temp = new Node; 
    temp->Next = Front;
    temp->Elem = NewNum;
    Front = temp;
    count++;
  }

} // comment the 2 cases
/**************************************************
PURPOSE: Deletes the element at the front of the linked list
PARAMETER: OldNum - element to be deleted
**************************************************/
void llist::deleteFront(el_t& OldNum) { 

  if(isEmpty()){
    throw Underflow();
  }
  if( count == 1){
    OldNum = Front->Elem;
    delete Front;
    count--;
    Front = NULL;
    Rear = NULL;
  }
  else {
    OldNum = Front->Elem;
    Node *temp;
    temp = Front->Next;
    delete Front;
    Front = temp;
    count--;
  }
} // comment the 3 cases
/********************************************
PURPOSE: Deletes the element at the rear of the linked list
PARAMETER: OldNum - the element to be deleted
********************************************/
void llist::deleteRear(el_t& OldNum){

  //cout << "IN FUNC" << endl;
  if(isEmpty()) {
    throw Underflow();
  }
  if (count == 1) {//special case.
    //cout << "IN SPECIAL CASE" << endl;
    OldNum = Rear->Elem;
    delete Rear;
    count--;
    Front = NULL;
    Rear = NULL;
  }
  else { 
    //cout << "IN ELSE, count=" << count <<  endl;
    OldNum = Rear->Elem;
    Node *P = Front;
    while( P->Next != Rear ){
      P = P->Next;
    }
    delete Rear;
    Rear = P;
    Rear->Next = NULL;
    count--;
  }

} // comment the 3 cases


/* harder ones follow */

// Utility Function to move a local pointer to the Jth node
void llist::moveTo(int J, Node*& temp)
{ // moves temp J-1 times to go to the Jth node
  // ** FINISH ** for ( int K = ... ) temp = temp->Next;
  temp = Front;
  for ( int k = 1; k <= J-1; k++) {
    temp = temp->Next;
  }
}
/************************************************
PURPOSE: Deletes the Ith node from the linked list
PARAMETER: I - index to delete, OldNum - refrence
variable to return removed item
************************************************/
void llist::deleteIth(int I, el_t& OldNum) { 

  Node* P;
  Node* Q;
  if (I > count || I < 1 ){//error case
    throw OutOfRange();
  }
  if(I == 1){//special case when deleting the front element
    deleteFront(OldNum);
  }
  else if(I == count){
    deleteRear(OldNum);
  }
  else{
    moveTo( I - 1, P );//move P to node before node to be deleted
    moveTo( I + 1, Q );//move Q to node after node to be deleted
    OldNum = P->Next->Elem;
    delete P->Next;
    P->Next = Q;
    count--;
  }
} // use moveTo to move local pointers. Be sure to comment to which node you are moving them. Do not forget to set OldNum.  
/***********************************************
PURPOSE: Inserts a node at the ith index
PARAMETER: I - index where item will be added,
newNum - the new item to be added
************************************************/
void llist::insertIth(int I, el_t newNum) {

  if(I > count+1 || I < 1){//error case

    throw OutOfRange();
  }
  if(I == 1 ){//special case when inserting at front 

    addFront(newNum);
  }
  else if(I == count+1) {//special case when inserting at the rear 

    addRear(newNum);
  }
  else{
    Node* P;
    //Node* Q;
    Node* temp = new Node;
    //cout<<"I="<<I<<endl;
    //moveTo(I+1, Q);//move pointer Q to node after where we want to insert.
    moveTo(I-1 , P);//move pointer P to node before where we want to insert
    
    temp->Elem = newNum;
    temp->Next = P->Next;
    P->Next = temp;
    
    count++;

  }
} // use moveTo to move local pointers. Be sure to comment to which node you are moving them.
/***********************************************
PURPOSE: Copy constructor or llist
PARAMETER: Original - orignal llist to be copied
***********************************************/
llist::llist(const llist& Original) { 

  //this->'s data members need to be initialized here first
  Front = NULL;
  Rear = NULL;
  count = 0;
  //this->object has to be built up by allocating new cells
  //and copying the values from Original into each cell
  Node* P;
  P = Original.Front;
  while(P != NULL){
    
    this->addRear(P->Elem);
    P = P->Next;
  }
} // use my code
/**********************************************
PURPOSE: Overloads the assignment operator
PARAMETER: OtherOne - Other linked list to be assigned
**********************************************/
llist& llist::operator=(const llist& OtherOne) { 
  el_t x;
  //First make sure this-> and OtherOne are not the same object.
  //To do this, cmpar the pointers to the objects.
  if( &OtherOne != this){ //if not the same
  
    //this->object has to be emptied first
    while(!this->isEmpty()){
      this->deleteRear(x);
    }
    //this->object has to be built up by allocating new cells with OtherOne elements
    Node* P;//local pointer for OtherOne
    P = OtherOne.Front;
    while( P != NULL) {
      this->addRear(P->Elem); //P's element is added to this->
      P = P->Next;            //Go to the next node in OtherOne
    }
  }
  return *this; // return the result unconditionally. Not that the result is returned by reference
} // use my code
