// CS311 Yoshii - Hash Table header DO NOT CHANGE!!! 
// ------------------------------------------------

#include "slist.h"
#include <iostream>

const int TSIZE = 37;  // 61 slots ; a prime number 

class htable
{
 private:
 slist table[TSIZE]; // each node of slist is PCB 
                          // as defined in PCB.h
 int hash(int);  // private hash function

 public:
  htable();
  ~htable();
  int deleteIt(PCB);
  int add(PCB);  // adds an element to the table and returns slot#
  PCB* find(int); // finds an element based on key and returns a pointer that points to it
  void displayTable(std::ostream&); // displays the table with slot#s

};
