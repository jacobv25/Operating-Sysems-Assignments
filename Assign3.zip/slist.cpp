// CS311 Yoshii Complete all functions with their comments

// ====================================================
//HW#: HW3P1 slist  inheriting from llist
//Your name: Jacob Valenzuela
//Complier:  g++
//File type: slist.cpp implementation file
//=====================================================

using namespace std;
#include<iostream>
#include"slist.h" 

// ** Make sure llist constructor and destructors have couts in them


// do not change this one
slist::slist()
{ //cout << "slist constructor: "<< endl;}
}

el_t* slist::search3(el_t X){
  el_t M;
  el_t* ptr;
  Node* P = Front;
  while(P != NULL){
    if(P->Elem == X){
      ptr = &P->Elem;
      return ptr;
    }
    P = P->Next;
  }
  ptr = &M;
  return ptr;
}

el_t slist::search2(el_t X){
  el_t M;
  Node* P = Front;
  while(P != NULL){
    if(P->Elem == X){
      return P->Elem;
    }
    P = P->Next;
  }
  return M;
}
// positions always start at 1
int slist::search(el_t key){

  Node* P = Front;
  int pos = 1;

  while(P != NULL){
    if(P->Elem == key){
      return pos;
    }
    pos++;
    P = P->Next;
  }
  return 0;
}

// don't forget to throw OutOfRange for bad pos 
void slist::replace(el_t element, int pos){

  if(pos < 1 || pos > count){
    throw OutOfRange();
  }
  Node* P;
  moveTo(pos, P);
  P->Elem = element;
}

bool slist::operator==(const slist& OtherOne){
  // if not the same length, return false
  if(this->count != OtherOne.count){
    return false;
  }
  // if the same lengths,
  //check each node to see if the elements are the same
  else{

    Node* P;
    P = this->Front;
    Node* Q;
    Q = OtherOne.Front;

    for(int i = 0; i < count; i++){
      if(P->Elem != Q->Elem){
	return false;
      }
      P = P->Next;
      Q = Q->Next;
    }
    return true;
  }
}
