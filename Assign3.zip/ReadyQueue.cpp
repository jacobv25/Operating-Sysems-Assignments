#include <iostream>
#include "ReadyQueue.h"
using namespace std;

// TODO: Add your implementation of ReadyQueue functions here
ReadyQueue::ReadyQueue()
{
  //rqueue = llist();
  readyCount = 0;
  highestPos = 0;
  for(int i = 0; i< 50; i++)
  {
    rqueue[i] = NULL;
  }

}

ReadyQueue::~ReadyQueue(){}



//adds a PCB representing a process into the ready queue.
void ReadyQueue::add(PCB* pcbPtr)
{
  int addPos=0; // index in rqueue where pcbPtr will be added
  bool foundPos = true;
  if(readyCount < 50)
  {
    while(foundPos) // goes through rqueue to find where to add pcbPtr
    {
      if(rqueue[addPos] == NULL) // searching full NULL position in list where pcbPtr can be added
      { 
        // note a position has been found
        foundPos = false;
      }
      else
      {
        addPos++;
      }
    }
    (*pcbPtr).setState(ProcState::READY);//change the state
    rqueue[addPos] = pcbPtr; // add pcbPtr at that position
    (*pcbPtr).pcbAddNum++;
    readyCount++;
  }

  findHighest();
  //cout << "Highest at: " << highestPos << " and ID is: \n" << (*rqueue[highestPos]).id << endl;

}

void ReadyQueue::addSJF(PCB* pcbPtr)
{
  int addPos=0; // index in rqueue where pcbPtr will be added
  bool foundPos = true;
  if(readyCount < 50)
  {
    while(foundPos) // goes through rqueue to find where to add pcbPtr
    {
      if(rqueue[addPos] == NULL) // searching full NULL position in list where pcbPtr can be added
      { 
        // note a position has been found
        foundPos = false;
      }
      else
      {
        addPos++;
      }
    }
    (*pcbPtr).setState(ProcState::READY);//change the state
    rqueue[addPos] = pcbPtr; // add pcbPtr at that position
    (*pcbPtr).pcbAddNum++;
    readyCount++;
  }
  //cout<<"adding..."<<endl;
  findHighestSJF();
  //cout << "Highest at: " << highestPos << " and ID is: \n" << (*rqueue[highestPos]).id << endl;

}
// remove and return the PCB with the highest priority from the queue
PCB* ReadyQueue::removeHighest()
{
  PCB* otherPCBptr;

  if(readyCount > 0)
  {
    otherPCBptr = rqueue[highestPos];
    //cout<<"made it here before"<<endl;
    //delete rqueue[highestPos]; // delete pointer
    //cout<<"made it here after"<<endl;
    rqueue[highestPos] = NULL; // release memory
    findHighest(); // find new highest for highestPos
    readyCount--;
    (*otherPCBptr).setState(ProcState::RUNNING);//change state
    (*otherPCBptr).pcbRemNum++; //increase count for num of times removed from readyqueue
  }
  return otherPCBptr;
}
// remove and return the PCB with the highest priority from the queue
PCB* ReadyQueue::removeHighestSJF()
{
  PCB* otherPCBptr;

  if(readyCount > 0)
  {
    otherPCBptr = rqueue[highestPos];
    //cout<<"made it here before"<<endl;
    //delete rqueue[highestPos]; // delete pointer
    //cout<<"made it here after"<<endl;
    rqueue[highestPos] = NULL; // release memory
    delete rqueue[highestPos]; //maybe?
    //cout<<"removing..."<<endl;//<- this line will print tho
    findHighestSJF(); // find new highest for highestPos
    readyCount--;
    (*otherPCBptr).setState(ProcState::RUNNING);//change state
    (*otherPCBptr).pcbRemNum++; //increase count for num of times removed from readyqueue
  }
  return otherPCBptr;
}

//Private function. Keeps track of where highest priority pointer is in readyqueue
void ReadyQueue::findHighest()
{
  int priorityTrack=0; //tracks priorities 
  int posTrack=0; // tracks positions

  if(readyCount > 0)
  {
    for(int i = 0; i < 50; i++)
    {
      if(rqueue[i] != NULL)
      {
        if(priorityTrack < (*rqueue[i]).priority)
        {
          posTrack = i;
          priorityTrack = (*rqueue[i]).priority;
        }
      }
      
    }
    highestPos = posTrack;
  }
}

//Private function. Keeps track of where highest priority pointer is in readyqueue
struct InverseBurstTime{
	float inverse;
};
void ReadyQueue::findHighestSJF()
{
	float highestPriority=0; //tracks priorities 
  int highPos=0; // tracks positions

  if(readyCount > 0)
  {
    for(int i = 0; i < 50; i++)
    {
			//cout<<"1"<<endl;
      if(rqueue[i] != NULL)
      {
				//cout<<"2"<<endl;
				InverseBurstTime inv_bt;
				inv_bt.inverse = (*rqueue[i]).burstTime;
				inv_bt.inverse = 1/inv_bt.inverse;//create the inverse
				//cout<<"inverse="<<inv_bt.inverse<<endl;
        if(highestPriority < inv_bt.inverse)
        {
					//cout<<"*************\n*************"<<endl;
          highPos = i;
          highestPriority = inv_bt.inverse;
					//cout<<"highestPriorityInsideIF="<<highestPriority<<endl;

        }
				//cout<<"highestPriority="<<highestPriority<<endl;

      }
      
    }
    highestPos = highPos;
  }
	/*********************
	int burstTrack=0; //tracks bursts 
  int posTrack=0; // tracks positions

  if(readyCount > 0)
  {
    //get first burst time in rqueue
    burstTrack = (*rqueue[0]).getBurstTime();
    posTrack = 0;

    if(readyCount == 1)
    {
      highestPos = posTrack;
    }
    else
    {
      for(int i = 1; i < readyCount; i++)
      {
        if((*rqueue[i]).getBurstTime() < burstTrack)
        {
          burstTrack = (*rqueue[i]).getBurstTime();
          posTrack = i;
        }
        
      }
      highestPos = posTrack;
    }
    
  }
	************************/
}//end of findHighestSJF

//============================================================
  /*
  int priorityTrack=0; //tracks priorities 
  int posTrack=0; // tracks positions
  float inverse_priority = 0.0;
  bool first_pass = true;
  if(readyCount > 0)
  {
    for(int i = 0; i < 50; i++)
    {
      if(rqueue[i] != NULL)
      {
        inverse_priority = (*rqueue[i]).burstTime;
        //invert
        cout<<"before inverse = " <<inverse_priority<<endl;
        inverse_priority = 1.0 / inverse_priority;
        cout<<"after inverse = " <<inverse_priority<<endl;
        if(inverse_priority < priorityTrack || first_pass)
        {
          first_pass = false;
          cout<<"++++++++++"<<endl;
          cout<<"inverseP="<<inverse_priority<<endl;
          posTrack = i;
          priorityTrack = inverse_priority;
        }
      }
      
    }
    cout<<"highest priority = "<<priorityTrack<<endl;
    highestPos = posTrack;
  }
  
  int indexOfHighest = 0;
  int currentBurst = -1;
  if(readyCount != 0)
  {
		//cout<<"2"<<endl;
    //case when 1 item in ready queue
		int count=0;
    if(readyCount == 1)
    {
      highestPos = indexOfHighest;
    }
    else
    {
			//cout<<"4"<<endl;
      //case when more than 1 item in ready queue
      currentBurst = (*rqueue[indexOfHighest]).getBurstTime();
      for(int i = 1; i < readyCount; i++)
      {//im tryign to check which one is triggering the fault
				cout<<"rq[i]= "<<(*rqueue[i]).getBurstTime()<<endl;
				cout<<"rq[IOH]= "<<(*rqueue[indexOfHighest]).getBurstTime()<<endl;

//old code? easier to work with
//you'll see what i mean

//damn idk....yeah but what's it supposed to be, if we knoewthat then we could find out where it's mucking up
//okay, so we know its using schedule.txt
//looking for shortest burst time
				cout<<"i="<<i<<endl;//i think its line 197
        if((*rqueue[i]).getBurstTime() < (*rqueue[indexOfHighest]).getBurstTime())
        {
					cout<<"test before"<<endl;
          indexOfHighest = i;
          currentBurst = (*rqueue[i]).getBurstTime();
					cout<<"test after"<<endl;	
				}

      }
      highestPos = indexOfHighest;
			
		}
  }
  */
//============================================================

/*****
void ReadyQueue::findHighest(){
  int tempHighest = 0; // assume index 0 contains the highest priority
  for(int i=0; i < readyCount; i++){
    //if rqueue[i] has a greater priority than the tempHighest
    if(rqueue[i]->priority > rqueue[tempHighest]->priority ){
        //then set rqueue[i] to be the newest tempHighest
        tempHighest = i;
    }
  }
  highestPos = tempHighest;
}
*****/
// Returns the number of elements in the queue.
int ReadyQueue::size()
{
  return readyCount;
}

// Prints the queue contents to standard output.
void ReadyQueue::display()
{
  for(int i = 0; i < 50; i++)
  {
    if(rqueue[i] != NULL)
    {
      cout << (*rqueue[i]) << endl;
    }
  }
}

bool ReadyQueue::isEmpty(){
  if (readyCount == 0){
      return true;
  }
  else { return false; }
}

bool ReadyQueue::contains(int pcbID)
{
  bool result=false;
    for(int i = 0; i < readyCount; i ++)
    {
      if(rqueue[i] != NULL && (*rqueue[i]).id == pcbID)
      {
        result=true;
      }
    }
    return result;
}//done