#include <iostream>
#include <ostream>
using namespace std;
#include "PCB.h"
// TODO: Add your implementation here


PCB::PCB()
{
  id = 0;
  priority = 0;
  state = ProcState::NEW;
  pcbAddNum = 0; // records number of times pcb added to readyqueue
  pcbRemNum = 0; // records number of times pcb removed from ready queue
}

PCB::PCB(unsigned int i, unsigned int p, ProcState s)
{
  id = i;
  priority = p;
  state = s;
}

PCB::~PCB(){}

void PCB::setPriority(int p)
{
  priority = p;
}

void PCB::setState(ProcState s)
{
  state = s;
}


void PCB::setID(int i)
{
  id = i;
}


//Overloading of = (returns a reference to a llist)
PCB& PCB::operator=(const PCB& Original)
{
  id = Original.id;
  priority = Original.priority;
  state = Original.state;
  return *this;
}

ostream& operator<<(ostream& O, const ProcState& St)
{
  O << static_cast<std::underlying_type<ProcState>::type>(St);
  return O;
}

ostream& operator<<(ostream& O, const PCB& P)
{
  string PCBprint =  "";
  PCBprint +="ID:";
  PCBprint += to_string(P.id);
  PCBprint +="\tPriority:";
  PCBprint += to_string(P.priority);
  PCBprint +="\tState:";

  string printState; // holds state of PCB as string
  switch(P.state)
  {
    case ProcState::NEW:
      printState = "NEW";
      break;
    case ProcState::RUNNING:
      printState = "RUNNING";
      break;  
    case ProcState::WAITING:
      printState = "WAITING";
      break;
    case ProcState::READY:
      printState = "READY";
      break;
    case ProcState::TERMINATED:
      printState = "TERMINATED";
      break;
  }
  
  O << PCBprint << printState;
  return O;
}


//jacob's attempt below 
//Marlo: I used some of this in the above overload of << operator


//===============================================}
//TODO: main.cpp will need some sort of way to access the PCBs in the table and switch their state. main.cpp will also need to have some sort of getter function that returns a PCB based on a given id.

PCBTable::PCBTable()
{
  //initialize count to 0
  PCBcount=0;
  //initialize pcbtable
  //for(int i=1; i <= PCB_SIZE;i++){pcbtable[i] = PCB(i, i, ProcState::NEW);}
}

PCBTable::~PCBTable(){}



void PCBTable::addPCB(PCB pObj)
{
  if(PCBcount < PCB_SIZE)
  {
    pcbtable[PCBcount] = pObj;
    PCBcount++;
  }
  else
  {
    throw PCBOutOfRange();
  }
}

//removes pcb from table and saves it to pObj//removes PCB from index in array specified by 'I'
void PCBTable::removePCB(int I, PCB &pObj)
{
  if(PCBcount > 0)
  {
    pObj = pcbtable[I];
    if(I != PCBcount-1) // if item removed wasn't the last item in the table
    {
      //shifting table so indices of remaining PCBs are sequential
      //this is needed because PCBs are always added at the end of the array in PCBTable::addPCB
      pcbtable[I] = pcbtable[PCBcount-1]; // move last item in table into gap
      pcbtable[PCBcount-1].~PCB(); // destroy last item after it is moved to fill gap
      PCBcount--; 
    }
  }
}

//REMEMBER TO CHANGE 30 BACK TO PCBcount: 'i < PCBcount;' - in for loop
void PCBTable::display(){
  for(int i=0; i < PCBcount; i++){
    std::cout << pcbtable[i] << endl;
  }
}

//returns pointer to PCB in pcbtable specified by priority pri
PCB* PCBTable::get(int id)
{
  for(int i = 0; i < PCBcount; i++)
  {
    if(pcbtable[i].id == id)
    { 
      PCB* tempPCBptr;
      tempPCBptr = &pcbtable[i];
      return tempPCBptr;
    }

  }
}

bool PCBTable::inTable(int searchID)
  {
    bool result=false;
    for(int i = 0; i < 50; i ++)
    {
      if(pcbtable[i].id == searchID)
      {
        result=true;
      }
    }
    return result;
  }

  //bool PCBTable::