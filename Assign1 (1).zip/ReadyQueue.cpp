#include <iostream>
#include "ReadyQueue.h"
using namespace std;

// TODO: Add your implementation of ReadyQueue functions here
ReadyQueue::ReadyQueue()
{
  //rqueue = llist();
  readyCount = 0;
  highestPos = 0;
  for(int i = 0; i< 50; i++)
  {
    rqueue[i] = NULL;
  }

}

ReadyQueue::~ReadyQueue(){}



//adds a PCB representing a process into the ready queue.
void ReadyQueue::add(PCB* pcbPtr)
{
  int addPos=0; // index in rqueue where pcbPtr will be added
  bool foundPos = true;
  if(readyCount < 50)
  {
    while(foundPos) // goes through rqueue to find where to add pcbPtr
    {
      if(rqueue[addPos] == NULL) // searching full NULL position in list where pcbPtr can be added
      { 
        // note a position has been found
        foundPos = false;
      }
      else
      {
        addPos++;
      }
    }
    (*pcbPtr).setState(ProcState::READY);//change the state
    rqueue[addPos] = pcbPtr; // add pcbPtr at that position
    (*pcbPtr).pcbAddNum++;
    readyCount++;
  }

  findHighest();
  //cout << "Highest at: " << highestPos << " and ID is: \n" << (*rqueue[highestPos]).id << endl;

}

// remove and return the PCB with the highest priority from the queue
PCB* ReadyQueue::removeHighest()
{
  PCB* otherPCBptr;

  if(readyCount > 0)
  {
    otherPCBptr = rqueue[highestPos];
    //cout<<"made it here before"<<endl;
    //delete rqueue[highestPos]; // delete pointer
    //cout<<"made it here after"<<endl;
    rqueue[highestPos] = NULL; // release memory
    findHighest(); // find new highest for highestPos
    readyCount--;
    (*otherPCBptr).setState(ProcState::RUNNING);//change state
    (*otherPCBptr).pcbRemNum++; //increase count for num of times removed from readyqueue
  }
  return otherPCBptr;


}

//Private function. Keeps track of where highest priority pointer is in readyqueue
void ReadyQueue::findHighest()
{
  int priorityTrack=0; //tracks priorities 
  int posTrack=0; // tracks positions

  if(readyCount > 0)
  {
    for(int i = 0; i < 50; i++)
    {
      if(rqueue[i] != NULL)
      {
        if(priorityTrack < (*rqueue[i]).priority)
        {
          posTrack = i;
          priorityTrack = (*rqueue[i]).priority;
        }
      }
      
    }
    highestPos = posTrack;
  }
}

/*****
void ReadyQueue::findHighest(){
  int tempHighest = 0; // assume index 0 contains the highest priority
  for(int i=0; i < readyCount; i++){
    //if rqueue[i] has a greater priority than the tempHighest
    if(rqueue[i]->priority > rqueue[tempHighest]->priority ){
        //then set rqueue[i] to be the newest tempHighest
        tempHighest = i;
    }
  }
  highestPos = tempHighest;
}
*****/
// Returns the number of elements in the queue.
int ReadyQueue::size()
{
  return readyCount;
}

// Prints the queue contents to standard output.
void ReadyQueue::display()
{
  for(int i = 0; i < 50; i++)
  {
    if(rqueue[i] != NULL)
    {
      cout << (*rqueue[i]) << endl;
    }
  }
}

bool ReadyQueue::isEmpty(){
  if (readyCount == 0){
      return true;
  }
  else { return false; }
}

bool ReadyQueue::contains(int pcbID)
{
  bool result=false;
    for(int i = 0; i < readyCount; i ++)
    {
      if(rqueue[i] != NULL && (*rqueue[i]).id == pcbID)
      {
        result=true;
      }
    }
    return result;
}//done