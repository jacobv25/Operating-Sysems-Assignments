// Remember to add comments to your code
#include <iomanip>
#include <iostream>
#include <cstdlib>
#include <time.h>
#include <sys/time.h>
using namespace std;
#include "PCB.h"
#include "ReadyQueue.h"
#include <bits/stdc++.h> 
// code to time the execution of 1,000,000 iterations taken from:
//https://www.geeksforgeeks.org/measure-execution-time-with-high-precision-in-c-c/

int main(int argc, char* argv[]) {
	//Print basic information about the program
	std::cout << "CS 433 Programming assignment 1" << std::endl;
	std::cout << "Author: Marlo Golding and Jacob Valenzuela" << std::endl;
	std::cout << "Date: 02/16/2021" << std::endl;
	std::cout << "Course: CS433 (Operating Systems)" << std::endl;
	std::cout << "Description : Program to implement a priority ready queue of processes" << std::endl;
	std::cout << "=================================" << std::endl;

	// TODO: Add your code for Test 1
	std::cout << "Performing Test 1" << std::endl;
  
  try
  {
    //create PCB_Table of 30 entries
    PCBTable pcb_table;
    
    //create 30 PCB entries and add them to the table
    for(int i = 1; i <= 30; i++){  
      int priority = i;
      PCB pcb(i, priority, ProcState::RUNNING);
      //cout << pcb << endl;
      pcb_table.addPCB(pcb);
    }

    //create ReadyQueue q1
    ReadyQueue q1;
    cout << "\nSub-Test 1: \nAdd processes 15, 6, 23, 29 and 8 to q1. Display the content of q1\n" << endl;
    

    
    q1.add(pcb_table.get(15));
    q1.add(pcb_table.get(6));
    q1.add(pcb_table.get(23));
    q1.add(pcb_table.get(29));
    q1.add(pcb_table.get(8));
    q1.display();//display the queue

    cout << "\nSub-Test 2: \nRemove the process with the highest priority from q1 and display q1\n" << endl;

    q1.removeHighest();
    q1.display();

    cout << "\nSub-Test 3: \nRemove the process with the highest priority from q1 and display q1\n" << endl;

    q1.removeHighest();
    q1.display();

    cout << "\nSub-Test 4: \nAdd processes 3, 17, 22, 12, 19 to q1 and display q1.\n" << endl;

        q1.add(pcb_table.get(3));
    q1.add(pcb_table.get(17));
    q1.add(pcb_table.get(22));
    q1.add(pcb_table.get(12));
    q1.add(pcb_table.get(19));
    q1.display();

    cout << "\nSub-Test 5: \nOne by one remove the process with the highest priority from the queue q1 and display the queue after each removal.\n" << endl;
    while(q1.size() != 0) 
    {
      q1.removeHighest();
      q1.display();
      cout << endl;
    }
    
  

  //TODO: Add your code for Test 2
	std::cout << "Performing Test 2" << std::endl;
  
  PCBTable pcb_table2;
  
  srand (time(NULL));
  int randPriority; 
  for(int i = 1; i <= 30; i++){
    
    randPriority = rand()%50 +1;  // for now
    PCB pcb(i, i, ProcState::RUNNING);
    pcb.setPriority(randPriority);
    pcb_table2.addPCB(pcb);
  }
  cout << "\nPCBTable 2" << endl;
  pcb_table2.display();

  //Initially, randomly select 15 processes from the PCB_table and add them into 𝑞1.
  cout<<endl;
  int id = 0;
  for(int i=0; i < 15; i++){
    id = rand() % 30 + 1;//randomly select a PCB using its ID
    q1.add(pcb_table2.get(id));//add a PCB item to the ReadyQueue using its ID
  }

  cout << "ReadyQueue q1:" << endl;
  q1.display();
  
  cout<<endl;
  /************************
  // PROCEDURE RUNS 1,000, 000 starts here
  *************************/

  clock_t start, end; // to kep time
  start = clock();
  bool condition;
  bool tf;//true or false
  int addHere; 
  //run the loop 1 million times
  for(long i = 0; i < 1000000; i++){   // let's start small
    //50% chance to add or remove a PCB
    tf = (rand() % 2) != 0;
    if(tf){//if true, add a PCB

      //if every PCB_Table has been added, do not add to it. Continue to the next iteration
      
      addHere = -1; // again
      for(int i = 1; i <= 30; i++)
      {
        if(addHere < 0 && (*pcb_table2.get(i)).state == ProcState::RUNNING)
        {
          addHere = i;
        }
      }
      
      if(addHere > 0) // at least 1 pcb was not yet in readyqueue
      {
        q1.add(pcb_table2.get(addHere));
      }
    }
    else{//remove a process
      
      if(!q1.isEmpty()){
        q1.removeHighest();
      }
      
    }
  
  }//end of for loop

  end = clock(); 

  //Print final contents of ready queue
  cout << "\nFinal contents of readyQueue q1:" << endl;
  q1.display();
   
  //int runTotal = 0;


  cout << "\nNumber of times each PCB was added/removed from  ReadyQueue\n" << endl;
  for(int i = 1; i <= PCB_SIZE; i++)
  {
    if(pcb_table2.inTable(i))
    {
      if((*pcb_table2.get(i)).pcbAddNum > 0 || (*pcb_table2.get(i)).pcbRemNum > 0)
      {
        //runTotal += (*pcb_table2.get(i)).pcbAddNum; 
        //runTotal += (*pcb_table2.get(i)).pcbRemNum;
        cout << left << setw(10) << "PCB\tID\t" << (*pcb_table2.get(i)).id << "\tadded\t";
        cout << (*pcb_table2.get(i)).pcbAddNum << " " << "\ttimes,";
        cout << "\tremoved\t" << (*pcb_table2.get(i)).pcbRemNum;
        cout << " " << "\ttimes" << endl;
      }
    }
  }

  //output time taken to do 1,000,000 cycles of above procedure
  double time_taken = double(end - start) / double(CLOCKS_PER_SEC); 
  cout << "Time Taken: " << time_taken << setprecision(15) << " seconds" << endl;

  //cout << "Total adds and removes: " << runTotal << endl;
 
  }//end of try
  catch(PCBTable::PCBOutOfRange)
  {
    cerr << "PCB not in Table" << endl;
  }
  

}