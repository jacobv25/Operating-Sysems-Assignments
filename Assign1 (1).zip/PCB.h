#pragma once

// Remember to add comments to your code
// ...

//number of elements in the PCBTable 
const int PCB_SIZE = 30;


// enum class of process state
// A process (PCB) in ready queue should be in READY state
enum class ProcState {NEW, READY, RUNNING, WAITING, TERMINATED};

/* 
Process control block(PCB) is a data structure representing a process in the system.
A process should have at least an ID and a state(i.e.NEW, READY, RUNNING, WAITING or TERMINATED).
It may also have other attributes, such as scheduling information (e.g. priority)
*/
class PCB {
public:
    // The unique process ID
	unsigned int id;
    // The priority of a process valued between 1-50. Larger number represents higher priority
	unsigned int priority;
	// The current state of the process.
	// A process in the ReadyQueue should be in READY state
  //for valid states see enum class ProcState
	ProcState state;

  long pcbAddNum; // records number of times pcb added to readyqueue
  long pcbRemNum; // records number of times pcb removed from ready queue

	// TODO: Add constructor and other necessary functions for the PCB class
  PCB(); // default onstructor; needed to intialize pcbtable
  PCB(unsigned int i, unsigned int p, ProcState s);

  //destructor to end a process object
  ~PCB();

  //PCB id
  static int PCB_id;

  //sets priority of a PCB; must be 1-50, inclusive. Larger number represents higher priority
  void setPriority(int p);

  //changes state of PCB
  void setState(ProcState s);
  
  //sets id of PCB. 
  void setID(int i);

  //Overloading of = (returns a reference to a PCB)
  PCB& operator=(const PCB&); 
  
  //allows PCB to be printed more easily using << operator and ostream obj cout
  friend std::ostream& operator<<(std::ostream&, const PCB&);
  friend std::ostream& operator<<(std::ostream&, const ProcState&);
};

/*
An array(list) of all PCB elements in the system.
*/



class PCBTable {
	// TODO: Add your implementation of the PCBTable
  /*
  PCBTable is an array object that contains PCB objects
  */
  private:
    
    //total of all pcbs tahat have been added to pcbtable
    int PCBcount;

    //array for PCB
    PCB pcbtable[PCB_SIZE];
    
    
  public:

    //constructor for PCBTable object
      PCBTable();

    //destructor for PCBTable object
      ~PCBTable();
    //add method to add PCBs to table
    
    //error classes
    class PCBUnderflow{};
    class PCBOutOfRange{};

    //adds process object to PCBTable
    void addPCB(PCB pObj);

    //removes PCB from PCBTable by index and saves it to pObj 
    void removePCB(int index, PCB &pObj);

    //returns pointer to PCB in pcbtable specified by priority pri
    PCB* get( int id);

    //************Added 2-14-2021************//
    //display the table
    void display();
    
    //returns true if supplied pcb id is in the pcbtable, false otherwise
    bool inTable(int searchID);


};