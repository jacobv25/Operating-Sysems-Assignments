#include "PageTable.h"

//====================PageTable Functions==================



PageTable::PageTable(int table_size)
{
  size = table_size;
  el_t pagetable[size];

  for(int i=0; i<size; i++)
  {
    el_t tempEntry;
    pagetable[i] = tempEntry;
  }
}


PageTable::~PageTable()
{}


bool PageTable::in_table(int pageNum)
{
  return hash_table.contains(pageNum);
}



el_t PageTable::getEntry(int pageNum)
{
  if(in_table(pageNum)){
    return hash_table.get(pageNum);
  }
}
// ADD ENTRY
void PageTable::addEntry(int pageNum, int frameNum)
{
  el_t entry(pageNum, frameNum);
  hash_table.add(entry);
}
// REMOVE ENTRY
void PageTable::removeEntry(el_t entry)
{
  hash_table.deleteItem(entry);
}

//====swap functions that simulate different=============
//====types of swap when paging table is full=============

//Show Table for testing
// void PageTable::showTable(){
//   hash_table.displayTable(std::cout);
// }

/*
PURPOSE:    Performs swap based on First In First Out    
PARAMETERS: 
*/
void PageTable::fifoSwap()
{}

/*
PURPOSE:    Performs swap randomly
PARAMETERS:
*/
void PageTable::randswap()
{}

/*
PURPOSE:    Performs swap based on Least Recently Used principle
PARAMETERS:
*/
void PageTable::lruswap()
{}

//================= end of swap functions ==============