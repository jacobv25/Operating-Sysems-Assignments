// Remember to add comments to your code

#include <iostream>
#include <iomanip>
#include <list>
#include <fstream>
#include <cstdlib>
#include <cmath>
#include <vector>
using namespace std;
#include "PageTable.h"
#include <time.h>
#include <sys/time.h>
#include <bits/stdc++.h> 


// code to time the execution of swap algorithms in Test 2 referenced from:
//https://www.geeksforgeeks.org/measure-execution-time-with-high-precision-in-c-c/

// Check if an integer is power of 2
bool isPowerOfTwo(unsigned int x)
{
	/* First x in the below expression is for the case when x is 0 */
	return x && (!(x & (x - 1)));
}


int main(int argc, char* argv[]) {
	//Print basic information about the program
	std::cout << "=================================================================" << std::endl;
	std::cout << "CS 433 Programming assignment 5" << std::endl;
	std::cout << "Author: Marlo Golding and Jacob Valenzuela" << std::endl;
	std::cout << "Date: 05/13/2021" << std::endl;
	std::cout << "Course: CS433 (Operating Systems)" << std::endl;
	std::cout << "Description : Program to simulate different page replacement algorithms" << std::endl;
	std::cout << "=================================================================\n" << std::endl;

	if (argc < 3) {
		// user does not enter enough parameters
		std::cout << "You have entered too few parameters to run the program.  You must enter" << std::endl
			<< "two command-line arguments:" << std::endl
			<< " - page size (in bytes): between 256 and 8192, inclusive" << std::endl
			<< " - physical memory size (in megabytes): between 4 and 64, inclusive" << std::endl;
		exit(1);
	}
	
	// Page size and Physical memory size 
	// Their values should be read from command-line arguments, and always a power of 2
	unsigned int page_size = atoi(argv[1]);
	if(!isPowerOfTwo(page_size))
	{
		std::cout << "You have entered an invalid parameter for page size (bytes)" << std::endl
			<< "  (must be an power of 2 between 256 and 8192, inclusive)." << std::endl;
		return 1;
	}
	unsigned int phys_mem_size = atoi(argv[2]) << 20; // convert from MB to bytes
	if(!isPowerOfTwo(phys_mem_size))
	{
		std::cout << "You have entered an invalid parameter for physical memory size (MB)" << std::endl
			<< "  (must be an even integer between 4 and 64, inclusive)." << std::endl;
		return 1;
	}

	// calculate number of pages and frames;
	int logic_mem_bits = 27;		// 27-bit logical memory (128 MB logical memory assumed by the assignment)
	int phys_mem_bits = std::log2(phys_mem_size);		// Num of bits for physical memory addresses, calculated from physical memory size, e.g. 24 bits for 16 MB memory
	int page_offset_bits = std::log2(page_size);				// Num of bits for page offset, calculated from page size, e.g. 12 bits for 4096 byte page
	// Number of pages in logical memory = 2^(logic_mem_bits - page_bit)
	int num_pages = 1 << (logic_mem_bits - page_offset_bits);
	// Number of free frames in physical memory = 2^(phys_mem_bits - page_offset_bits)
	int num_frames = 1 << (phys_mem_bits - page_offset_bits);


  int references = 0; // holds count of number of references 
  int faults = 0; // holds count of number of faults 
  int replacements = 0; // holds count of number of replacements
	//int frame_number = 0; // holds frame number page number is at or was assigned
  int fault_bit = 1;//fault bit is always 1 during first entry
  int frame_number = -1;
  int temp_frame_num = -1;
  int logical_address, page_number;
  el_t temp_entry;

	std::cout << "Page size = " << page_size << " bytes" << std::endl;
	std::cout << "Physical Memory size = " << phys_mem_size << " bytes" << std::endl;
	std::cout << "Number of pages = " << num_pages << std::endl; 
	std::cout << "Number of physical frames = " << num_frames << std::endl;

	// Test 1: Read and simulate the small list of logical addresses from the input file "small_refs.txt"
	std::cout <<"\n================================Test 1==================================================\n";
	// TODO: Add your code here for test 1 that prints out logical page #, frame # and whether page fault for each logical address
  

  ifstream infile;
  infile.open("small_refs.txt");
  string line;
  if(infile.is_open())
  {
    
    //Construct Page Table using num_frames as table size. I think this is correct.
    PageTable page_table(num_frames);


    while(getline(infile, line))
    {
      //1. references
      logical_address = stoi(line);
      references++;
      
      //2. page number
      page_number = logical_address >> page_offset_bits; // shift left by 8 (256 = 2^8)

      //3. & 4. frame_number and fault_bit 
      //check if the page_number is already in the page table
      // cout << page_table.in_table(page_number) <<endl;
      if(page_table.in_table(page_number)==0){
        //cout<<"not found...adding"<<endl;
        faults++;
        //if page is not in the page table, set page fault to TRUE
        fault_bit = 1;
        //increment frame_number
        frame_number = temp_frame_num;
        frame_number++;
        //keeps track of old frame number before reset to zero
        temp_frame_num = frame_number;
        page_table.addEntry(page_number, frame_number);
    
      }
      else{
        //cout<<"already exists"<<endl;
        fault_bit = 0;
        temp_entry = page_table.getEntry(page_number);
        frame_number = temp_entry.getFrameNum();
      }

      //page_table.showTable();
      //print data
      cout << "Logical address: " << logical_address << ",\t";
      cout << "page number: " << page_number << ",\t";
      cout << "frame number = " << frame_number << ",";
      cout << "\tis page fault? " << fault_bit << endl;

      
    }
    infile.close();
  }
  else 
  {
    cerr << "Error - could not open small_refs.txt" << endl;
  }

  //print out result of simulation
  cout << "Number of references: \t" << references << endl;
	cout << "Number of faults: \t" << faults << endl;
  cout << "Number of replacements: \t" << replacements << endl;

/**********************************************************************
*********************   TEST 2 **************************************
**********************************************************************/
	// Test 2: Read and simulate the large list of logical addresses from the input file "large_refs.txt"
	std::cout <<"\n================================Test 2==================================================\n";
  fault_bit = 1;//fault bit is always 1 during first entry

  infile.open("large_refs.txt");
  line = "";

	std::cout << "****************Simulate FIFO replacement****************************" << std::endl;
	// TODO: Add your code to calculate number of page faults using FIFO replacement algorithm	
  //Keep track of time passed

  references = 0; // reset references count to 0
  faults = 0;
	clock_t start1, end1; // to keep time
  start1 = clock(); // clock started

  //*******[code here using FIFO swap algorithm]
if(infile.is_open())
{
    // To represent set of current pages. We use 
    // an unordered_set so that we quickly check 
    // if a page is present in set or not 
    unordered_set<int> s; 
  
    // To store the pages in FIFO manner 
    queue<int> indexes; 
  
    // Start from initial page 
    while(getline(infile,line))
    {
      //1. references
      logical_address = stoi(line);
      references++;
      //2. page number
      page_number = logical_address >> page_offset_bits; // shift left by 8 (256 = 2^8)

      if(s.size() < num_frames)
      {
        // Insert it into set if not present 
        // already which represents page fault 
        if (s.find(page_number)==s.end()) 
        { 
          s.insert(page_number); 
  
          // increment page fault 
          faults++;
  
          // Push the current page into the queue
          indexes.push(page_number); 
        }
      }
      // If the set is full then need to perform FIFO 
      // i.e. remove the first page of the queue from 
      // set and queue both and insert the current page 
      else
      { 
        // Check if current page is not already 
        // present in the set 
        if (s.find(page_number) == s.end()) 
        { 
          //Pop the first page from the queue 
          int val = indexes.front(); 
  
          indexes.pop(); 
  
          // Remove the indexes page 
          s.erase(val); 
  
          // insert the current page 
          s.insert(page_number); 
  
          // push the current page into 
          // the queue 
          indexes.push(page_number); 
  
          // Increment page faults 
          faults++; 

          //increment replacements
          replacements++;
        } 
      } 
    }  
  }

  
  end1 = clock();
  double time_taken1 = double(end1 - start1) / double(CLOCKS_PER_SEC);

	// TODO: print the statistics and run-time
  cout << "Number of references: \t" << references << endl;
	cout << "Number of faults: \t" << faults << endl;
  cout << "Number of replacements: \t" << replacements << endl;
  cout << "Elapsed time = " << setprecision(7) << fixed << time_taken1 << " seconds" << endl;





	std::cout << "****************Simulate Random replacement**************************" << std::endl;


	// TODO: Add your code to calculate number of page faults using Random replacement algorithm

  //reset variables
  references = 0; // reset references count to 0
  faults = 0;
  replacements= 0;

  clock_t start2, end2; // to keep time
  start2 = clock(); // clock started

  srand (time(NULL));

  //clear and reset the getline
  infile.clear();
  infile.seekg (0, ios::beg);

  //*******[code here using Random swap algorithm]
  /******************************************************
/*************************************************************/
  vector<int> vector;
  unordered_set<int> set;
  slist linked_list_q;
  int count = 0, index = 0;

  if(infile.is_open())
  {    
    //Construct Page Table using num_frames as table size. I think this is correct.
    //PageTable page_table3(num_frames);
    //While there are still references to read from the text file.
    while(getline(infile, line))
    {
      //1. references
      logical_address = stoi(line);
      references++;
      //cout<<"references="<<references<<endl;
      //2. page number
      page_number = logical_address >> page_offset_bits; // shift left by 8 (256 = 2^8)

      if(set.find(page_number)==set.end()){
        //cout<<"not found...adding"<<endl;
        faults++;
        //if page is not in the page table, set page fault to TRUE
        fault_bit = 1;
        //check if full
        if(count < num_frames){
          el_t entry(page_number, 0);
          //linked_list_q.addRear(entry);
          vector.push_back(page_number);
          set.insert(page_number);
          count++;
          //page_table3.addEntry(page_number, frame_number);
        }
        else{
          //random swap
          //remove from linked queue and PageTable
          index = rand() % count+1;
          //linked_list_q.deleteIth(index, temp_entry);
          int old_page = vector[index];
          std::swap(vector[index], vector[count-1]);
          //el_t new_entry(new_page_num,0);
          vector.pop_back();
          //page_table3.removeEntry(temp_entry);
          set.erase(old_page);
          //create the new entry to take the spot of the old
          //el_t entry(page_number, new_entry.getFrameNum());
          //add it to the rear of the linked_list_queue
          //linked_list_q.addRear(entry);
          vector.push_back(page_number);
          set.insert(page_number);
          //page_table3.addEntry(page_number, new_entry.getFrameNum());
          replacements++;
        }  
      }
      
    }
    infile.close();
  }
  else 
  {
    cerr << "Error - could not open large_refs.txt" << endl;
  }
  /***********************************/

  end2 = clock();
  double time_taken2 = double(end2 - start2) / double(CLOCKS_PER_SEC);

	// TODO: print the statistics and run-time
  cout << "Number of references: \t" << references << endl;
	cout << "Number of faults: \t" << faults << endl;
  cout << "Number of replacements: \t" << replacements << endl;
  cout << "Elapsed time = " << setprecision(7) << fixed << time_taken2 << " seconds" << endl;

/**************************************************************/

	std::cout << "****************Simulate LRU replacement****************************" << std::endl;
  cout << "IGNORE BELOW" << endl;
	// TODO: Add your code to calculate number of page faults using LRU replacement algorithm

  references = 0; // reset references count to 0 
  faults = 0; // holds count of number of faults 
  replacements = 0; // holds count of number of replacements
  fault_bit = 1;//fault bit is always 1 during first entry
  frame_number = -1;
  temp_frame_num = -1;
  // el_t temp_entry_;
  int capacity = num_frames;
  int n = 2000000;
  int pages[n];

  infile.open("large_refs.txt");

  int j=0;
  while(getline(infile, line)){
    //cout<<"adding "<< line <<" to pages[]"<<endl;
    pages[j] = stoi(line);
    j++;
  }
  references = j;

  clock_t start3, end3; // to keep time
  start3 = clock(); // clock started


  //*******[code here using LRU swap algorithm]***********


  // cout<<"\ndisplay pages[]:"<<endl;
  // for(int i=0; i<n; i++){
  //   cout<<pages[i]<<endl;
  // }


	// To represent set of current pages. We use
	// an unordered_set so that we quickly check
	// if a page is present in set or not
	unordered_set<int> s;

	// To store least recently used indexes
	// of pages.
	unordered_map<int, int> indexes;

	// Start from initial page
	int page_faults = 0;
	for (int i=0; i<n; i++)
	{
		// Check if the set can hold more pages
		if (s.size() < capacity)
		{
			// Insert it into set if not present
			// already which represents page fault
			if (s.find(pages[i])==s.end())
			{
				s.insert(pages[i]);

				// increment page fault
				page_faults++;
			}

			// Store the recently used index of
			// each page
			indexes[pages[i]] = i;
		}

		// If the set is full then need to perform lru
		// i.e. remove the least recently used page
		// and insert the current page
		else
		{
			// Check if current page is not already
			// present in the set
			if (s.find(pages[i]) == s.end())
			{
				// Find the least recently used pages
				// that is present in the set
				int lru = INT_MAX, val;
				for (auto it=s.begin(); it!=s.end(); it++)
				{
                   	//cout<<"checking who to replace..."<<endl;
                  	// cout<<"map so far:"<<endl;
                  	// for( auto iter=s.begin(); iter!=s.end(); iter++)
                    // {
                    //  	cout<<*iter<<endl; 
                    // }
                    //cout<<"(map[*it] < lru)?"<<endl;
                    //cout<<"("<<indexes[*it]<<" < "<<lru<<")?"<<endl;                  
					if (indexes[*it] < lru)
                    {
						lru = indexes[*it];
                       	//cout<<"new LRU="<<lru<<endl;
						val = *it;
                      	//cout<<"new val="<<val<<endl;
					}
				}
                //cout<<"REPLACING "<< val << endl;
              
				// Remove the indexes page
				s.erase(val);

				// insert the current page
				s.insert(pages[i]);

				// Increment page faults
				page_faults++;
        // Increment page faults
      	replacements++;
			}

			// Update the current page index
			indexes[pages[i]] = i;
		}
    // cout << "page number: " << page_number << ",\t";
    // cout << "frame number = " << frame_number << ",";
    // cout << "\tis page fault? " << fault_bit << endl;
	}

  /******************************************************

  // To represent set of current pages. We use
  // an unordered_set so that we quickly check
  // if a page is present in set or not
  unordered_set<int> us;
  
  // To store least recently used indexes
  // of pages.
  unordered_map<int, int> map;

  //Page Table for testing. Hardcoded with size 3.
  PageTable pt(3);

  //infile.open("large_refs.txt");
  //infile.open("custom_refs.txt");

  //cout<<"is file open?="<<infile.is_open()<<endl;
  if(infile.is_open()){
    //cout<<"file opened.."<<endl;
    while(getline(infile, line))
    {

      //1. references
      logical_address = stoi(line);
      references++;
      //cout<<"references="<<references<<endl;
      //2. page number
      page_number = logical_address;// >> page_offset_bits; // shift left by 8 (256 = 2^8)

      //cout<<"getting line"<<endl;
      // Check if the set can hold more pages
      //HARD CODED 3, BUT SHOULD WORK WITH num_frames
        if (us.size() < 3)
        {
          //cout<<"avail to add"<<endl;
            // Insert it into set if not present
            // already which represents page fault
            if (us.find(page_number)==us.end())
            {
              //cout<<"not present"<<endl;
                us.insert(page_number);
  
                // increment page fault
                faults++;
                //set fault bit
                fault_bit = 1;
                //increment frame_number
                frame_number = temp_frame_num;
                frame_number++;
                //keeps track of old frame number before reset to zero
                temp_frame_num = frame_number;

                //insert in pt for testing
                pt.addEntry(page_number, frame_number);
            }
  
            // Store the recently used index of
            // each page (line number from text file)
            map[page_number] = references-1;
        }
  
        // If the set is full then need to perform lru
        // i.e. remove the least recently used page
        // and insert the current page
        else
        {
            cout<<"FULL!"<<endl;
            // Check if current page is not already
            // present in the set
            if (us.find(page_number) == us.end())
            {
                cout<<"need to replace..."<<endl;
                // Find the least recently used pages
                // that is present in the set
                int lru = INT_MAX, val;
                for (auto it=us.begin(); it!=us.end(); it++)
                {
                  cout<<"checking who to replace..."<<endl;
                  cout<<"map so far:"<<endl;
                  	for( auto iter=us.begin(); iter!=us.end(); iter++)
                    {
                     	cout<<"\t"<<*iter<<endl; 
                    }
                    cout<<"(map[*it] < lru)?"<<endl;
                    cout<<"("<<map[*it]<<" < "<<lru<<")?";
                    if (map[*it] < lru)
                    {
                      cout<<" yes"<<endl;
                        lru = map[*it];
                        cout<<"LRU="<<lru<<endl;
                        val = *it;
                    }
                }
                cout<<"\nREPLACING "<< val << endl;
                //page_number = val;
                el_t entry;

                entry = pt.getEntry(val);
  
                // Remove the indexes page
                us.erase(val);

                //remove from pt
                old_frame_num = entry.getFrameNum();

                pt.removeEntry(entry);
  
                // insert the current page
                us.insert(page_number);

                pt.addEntry(page_number, old_frame_num);
  
                // Increment page faults
                faults++;

                // Increment replacements
                replacements++;
            }
            else{
              //cout<<"already exists"<<endl;
              fault_bit = 0;
              temp_entry = pt.getEntry(page_number);
              frame_number = temp_entry.getFrameNum();
            }
            // Update the current page index (line number from text file)
            map[page_number] = references-1;
        }
        
        //page_table.showTable();
        //print data
        //cout << "Logical address: " << logical_address << ",\t";
        cout << "page number: " << page_number << ",\t";
        cout << "frame number = " << frame_number << ",";
        cout << "\tis page fault? " << fault_bit << endl;
    }
  }
  */

  end3 = clock();
  double time_taken3 = double(end3 - start3) / double(CLOCKS_PER_SEC);

	// TODO: print the statistics and run-time
  cout << "Number of references: \t" << references << endl;
	cout << "Number of faults: \t" << page_faults << endl;
  cout << "Number of replacements: \t" << replacements << endl;
  cout << "Elapsed time = " << setprecision(7) << fixed << time_taken3 << " seconds" << endl;
    
}