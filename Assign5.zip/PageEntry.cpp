#include "PageEntry.h"

PageEntry::PageEntry(int pn, int fn)
{
  page_num = pn;
  frame_num = fn;
  //**Below attributes were initialized in .h file
  //bool valid;
  //bool dirty;
}

PageEntry::~PageEntry()
{}

int PageEntry::getkey()
{
  return page_num;
}

//Overloading of = (returns a reference to a llist)
PageEntry& PageEntry::operator=(const PageEntry& Original)
{
  page_num = Original.page_num;
  page_num = Original.page_num;
  valid = Original.valid;
  dirty = Original.dirty;
  return *this;
}

// overload == for search based on the key part only
bool PageEntry::operator==(PageEntry OtherOne)
{
  if (page_num == OtherOne.page_num) return true; else return false;
}

bool PageEntry::operator!=(PageEntry OtherOne)
{
  if (page_num != OtherOne.page_num) return true; else return false;
}

ostream& operator<<(ostream& O, const PageEntry& P)
{
  string PageEntryprint =  "";
  PageEntryprint +="Page Number:";
  PageEntryprint += to_string(P.page_num);
  PageEntryprint +="\Frame Number:";
  PageEntryprint += to_string(P.frame_num);
  PageEntryprint +="\tValid?:";
  PageEntryprint += to_string(P.valid);
  PageEntryprint +="\tDirty?:";
  PageEntryprint += to_string(P.dirty);

  O << PageEntryprint;
  return O;
}
