#pragma once
#include <bits/stdc++.h> 
#include "htable.h"
//#include "PageEntry.h"

/**
 * \brief A page table is like an array of page entries. The size of the page table should equal to the number of pages in logical memory
 */
class PageTable
{
	// TODO: Add your implementation of the page table here
  private:

    //The actuale table
    htable hash_table;
    //Page Entry Container for quick searching 
    //std::unordered_set<PageEntry> set
    //vector container for random access
    // std::vector<PageEntry> vector
    // //queue for FIFO replacement
    // std::queue<PageEntry> queue

    int size;// max size of the paging table

    //====internal functions that simulate different types of swap =====
    
    //simulates FIFO swap
    void fifoSwap();

    //simulates random swap
    void randswap();

    //simulates LRU swap
    void lruswap();
    //================= end of swap functions =================

  public:
  
  //constructor and destructor for PageTable class
  PageTable(int);
  ~PageTable();

  //returns true if PageEntry at in is valid in table
  bool in_table(int pageNum);
  //gets an entry based on PageNumber
  el_t getEntry(int pageNum);
  //add entry to page table
  //this function uses er at which
  //returns int - frame number at which page was added
  void addEntry(int page_number, int frameNum);
  //removes a entry from the page table
  void removeEntry(el_t);

  void showTable();
};
