class PageEntry 
{

  public:
    PageEntry(int,int);
    ~PageEntry();
    int getkey();
    bool operator==(PageEntry);  // overload == for search
    bool operator!=(PageEntry);  // overload != for search
    //Overloading of = (returns a reference to a PCB)
    PageEntry& operator=(const PageEntry&); 
  
    //allows PCB to be printed more easily using << operator and ostream obj cout
    friend std::ostream& operator<<(std::ostream&, const PageEntry&);

    int getFrameNum();
  private:
    int page_num;
    int frame_num;
    int valid = 0;
    int dirty = 0;
}