/**
 * Driver program
 *
 * Add other data structures and .cpp and .h files as needed.
 *
 *
 * 1. Get command line arguments argv[1],argv[2],argv[3] 
 * 2. Initialize buffer 
 * 3. Create producer thread(s) 
 * 4. Create consumer thread(s) 
 * 5. Sleep 
 * 6. Exit 
 */

#include <cstdlib>
#include <iostream>
#include <pthread.h>
#include <semaphore.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>   
using namespace std;

//********FUNCTIONS FOR CONSUMER AND PRODUCER*************(BELOW)
sem_t semEmpty;
sem_t semFull;

pthread_mutex_t mutexBuffer;
const int BUFFER_MAX = 5;
int buffer[BUFFER_MAX];
int count = 0;
time_t start;
int sleep_time = 0;

void printBuffer()
{
  cout << "[";
  for(int i = 0; i < count; i++)
  {
    cout << buffer[i] << " ";
  }
  cout << "]" << endl;
}

void removeTask(int &task)
{
  //remove task
  task = buffer[0];
  count--;
  //shift items down
  for(int i =0; i < count; i++)
  {
    buffer[i] = buffer[i+1];
  }
}

void addTask(int x)
{
  if(count < BUFFER_MAX)
  {
    buffer[count] = x;
    count++;
  }
	else {
		printf("Skipped %d\n", x);
	}
}


void* producer(void* args) {
    double seconds_since_start;
    while (1) {
				//check if time has expired
				seconds_since_start = difftime( time(0), start);
				if(seconds_since_start > sleep_time){
					exit(1);//if expired, exit program
				}
        // Produce
				//sleep for a random amount of time
        usleep(rand()%1000000);
				//generate random num from 1-100
        int x = rand() % 100;
        // Add to the buffer
        sem_wait(&semEmpty);
        pthread_mutex_lock(&mutexBuffer);
        
        addTask(x);
        //count++;
        //----------------------------------------------
        cout << "\nitem " << x << " inserted by a producer." << endl;
        cout << "The current content of the buffer is ";
        printBuffer();
        //usleep(rand()%50000);
        //----------------------------------------------
        pthread_mutex_unlock(&mutexBuffer);
        sem_post(&semFull);
    }
}

void* consumer(void* args) {
    double seconds_since_start;
    while (1) {
				//check if time expired
				seconds_since_start = difftime( time(0), start);
				if(seconds_since_start > sleep_time){
					exit(1);//if expired exit program
				}
        int y=-1;
				//sleep for a random amount of time
        usleep(rand()%1000000);
        // Remove from the buffer
        sem_wait(&semFull);
        pthread_mutex_lock(&mutexBuffer);
        //y = buffer[count - 1];
        //count--;
				if(count > 0){
        	removeTask(y);
				}	
        //----------------------------------------------
        cout << "\nitem " << y << " removed by a consumer." << endl;
        cout << "The current content of the buffer is ";
        printBuffer();
        //usleep(rand()%1000000);
        //----------------------------------------------
        pthread_mutex_unlock(&mutexBuffer);
        sem_post(&semEmpty);

        // Consume

        //printf("Got %d\n", y);
        //sleep(1);
    }
}
//********FUNCTIONS FOR CONSUMER AND PRODUCER*************(ABOVE)

int main(int argc, char *argv[])
{
	//Keep Track of Start Time
	start = time(0);

  std::cout << "CS 433 Programming assignment 4" << std::endl;
  std::cout << "Author: Marlo Golding and Jacob Valenzuela" << std::endl;
  std::cout << "Date: 04/29/2021" << std::endl;
  std::cout << "Course: CS433 (Operating Systems)" << std::endl;
  std::cout << "Description : Solves the producer-consumer problem using semaphores and the POSIX thread (pthread) API. " << std::endl;
  std::cout << "=================================" << std::endl;

  int sleeptime, numConsumer, numProducer, numThreads;

  if(argc < 4)
  {
    cerr << "You have entered too few parameters to run the program.";cerr << "\nYou must enter three command-line arguments:";
    cerr << "\n- amount of time to run the program (in seconds, positive integer";
    cerr << "\n  that is nonzero)";
    cerr << "\n- number of producer threads to create (positive integer or zero)";
    cerr << "\n- number of consumer threads to create (positive integer or zero)" << endl;
    exit(0);
  }
  else
  {
    //
    
    sleeptime = int(*argv[1])-48;
		sleep_time = int(*argv[1])-48;
    numProducer = int(*argv[2])-48;
    numConsumer = int(*argv[3])-48;
    numThreads = numConsumer + numProducer;



    cout << "sleeptime: " << sleeptime << " numConsumer: " << numConsumer << " numProducer: " << numProducer << endl;
  }

  //arguments attained now to design producer and consumer threads

	/***************************************
			BUFFER HAS BEEN INITIALIZED
	**************************************/
	/**************************************
	    CREATE PRODUCER THREADS
	*************************************/

    srand(time(NULL));
		//array of threads
    pthread_t th[numThreads];
		//mutex lock
    pthread_mutex_init(&mutexBuffer, NULL);
    //semaphores
		sem_init(&semEmpty, 0, BUFFER_MAX);
    sem_init(&semFull, 0, 0);
    
    int i;

		// **************CREATE PRODUCER THREADS********************
		for(i=0; i<numProducer; i++){
			if (pthread_create(&th[i], NULL, &producer, NULL) != 0) {
        perror("Failed to create producer thread");
      }
		}
		// **************CREATE CONSUMER THREADS********************
		for(i=0; i<numConsumer; i++){
			if (pthread_create(&th[i], NULL, &consumer, NULL) != 0) {
        perror("Failed to create consumer thread");
      }
		}

    for (i = 0; i < numThreads; i++) {
        if (pthread_join(th[i], NULL) != 0) {
            perror("Failed to join thread");
        }
    }
    sleep(sleeptime);//what u do?

    //destroy semaphores and mutex lock
    sem_destroy(&semEmpty);
    sem_destroy(&semFull);
    pthread_mutex_destroy(&mutexBuffer);
    return 0;

  return 0;
}